# Practical Task 1
"Development and Build Tools (ENG)" module:

Create a program that takes a sequence of symbols (string) as arguments from the command line and prints the maximum number of unequal consecutive characters per line to the console.
